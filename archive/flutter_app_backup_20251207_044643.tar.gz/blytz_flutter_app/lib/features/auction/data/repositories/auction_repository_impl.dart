import 'package:blytz_flutter_app/core/network/api_client.dart';
import 'package:blytz_flutter_app/core/errors/failures.dart';
import 'package:blytz_flutter_app/features/auction/data/models/auction_model.dart';
import 'package:dio/dio.dart';
import 'package:either_dart/either.dart';

abstract class AuctionRepository {
  Future<Either<Failure, List<AuctionModel>>> getAuctions({
    int page = 1,
    int limit = 20,
    String? category,
    String? status,
    String? sellerId,
  });

  Future<Either<Failure, List<AuctionModel>>> getActiveAuctions({
    int page = 1,
    int limit = 20,
  });

  Future<Either<Failure, AuctionModel>> getAuction(String id);
  Future<Either<Failure, List<BidModel>>> getAuctionBids(String id, {int page = 1, int limit = 20});
  Future<Either<Failure, BidModel>> placeBid(String auctionId, double amount);
  Future<Either<Failure, AuctionModel>> createAuction(Map<String, dynamic> auctionData);
  Future<Either<Failure, AuctionModel>> updateAuction(String id, Map<String, dynamic> auctionData);
  Future<Either<Failure, void>> deleteAuction(String id);
}

class AuctionRepositoryImpl implements AuctionRepository {

  AuctionRepositoryImpl({required ApiClient apiClient}) : _apiClient = apiClient;
  final ApiClient _apiClient;

  @override
  Future<Either<Failure, List<AuctionModel>>> getAuctions({
    int page = 1,
    int limit = 20,
    String? category,
    String? status,
    String? sellerId,
  }) async {
    try {
      final response = await _apiClient.getAuctions(
        page: page,
        limit: limit,
        category: category,
        status: status,
        sellerId: sellerId,
      );

      final auctions = (response['auctions'] as List<dynamic>?)
          ?.map((json) => AuctionModel.fromJson(json as Map<String, dynamic>))
          .toList() ?? [];

      return Right(auctions);
    } on DioException catch (e) {
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<AuctionModel>>> getActiveAuctions({
    int page = 1,
    int limit = 20,
  }) async {
    try {
      final response = await _apiClient.getActiveAuctions(page: page, limit: limit);

      final auctions = (response['auctions'] as List<dynamic>?)
          ?.map((json) => AuctionModel.fromJson(json as Map<String, dynamic>))
          .toList() ?? [];

      return Right(auctions);
    } on DioException catch (e) {
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, AuctionModel>> getAuction(String id) async {
    try {
      final response = await _apiClient.getAuction(id);
      final auction = AuctionModel.fromJson(response);
      return Right(auction);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) {
        return const Left(NotFoundFailure('Auction not found'));
      }
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, List<BidModel>>> getAuctionBids(String id, {int page = 1, int limit = 20}) async {
    try {
      final response = await _apiClient.getAuctionBids(id, page: page, limit: limit);

      final bids = (response['bids'] as List<dynamic>?)
          ?.map((json) => BidModel.fromJson(json as Map<String, dynamic>))
          .toList() ?? [];

      return Right(bids);
    } on DioException catch (e) {
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, BidModel>> placeBid(String auctionId, double amount) async {
    try {
      final response = await _apiClient.placeBid(
        'Bearer YOUR_TOKEN_HERE', // TODO: Get from auth repository
        auctionId,
        {'amount': amount},
      );

      final bid = BidModel.fromJson(response['bid'] as Map<String, dynamic>);
      return Right(bid);
    } on DioException catch (e) {
      if (e.response?.statusCode == 400) {
        return const Left(ValidationFailure('Invalid bid amount'));
      } else if (e.response?.statusCode == 401) {
        return const Left(AuthFailure('Authentication required'));
      } else if (e.response?.statusCode == 403) {
        return const Left(AuthFailure('Cannot bid on your own auction'));
      }
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, AuctionModel>> createAuction(Map<String, dynamic> auctionData) async {
    try {
      final response = await _apiClient.createAuction(
        'Bearer YOUR_TOKEN_HERE', // TODO: Get from auth repository
        auctionData,
      );

      final auction = AuctionModel.fromJson(response['auction'] as Map<String, dynamic>);
      return Right(auction);
    } on DioException catch (e) {
      if (e.response?.statusCode == 400) {
        return const Left(ValidationFailure('Invalid auction data'));
      } else if (e.response?.statusCode == 401) {
        return const Left(AuthFailure('Authentication required'));
      }
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, AuctionModel>> updateAuction(String id, Map<String, dynamic> auctionData) async {
    try {
      final response = await _apiClient.updateAuction(
        'Bearer YOUR_TOKEN_HERE', // TODO: Get from auth repository
        id,
        auctionData,
      );

      final auction = AuctionModel.fromJson(response['auction'] as Map<String, dynamic>);
      return Right(auction);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) {
        return const Left(NotFoundFailure('Auction not found'));
      } else if (e.response?.statusCode == 401) {
        return const Left(AuthFailure('Authentication required'));
      } else if (e.response?.statusCode == 403) {
        return const Left(AuthFailure('Cannot modify this auction'));
      }
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, void>> deleteAuction(String id) async {
    try {
      await _apiClient.deleteAuction(
        'Bearer YOUR_TOKEN_HERE', // TODO: Get from auth repository
        id,
      );

      return const Right(null);
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) {
        return const Left(NotFoundFailure('Auction not found'));
      } else if (e.response?.statusCode == 401) {
        return const Left(AuthFailure('Authentication required'));
      } else if (e.response?.statusCode == 403) {
        return const Left(AuthFailure('Cannot delete this auction'));
      }
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }
}
// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'bid_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

BidModel _$BidModelFromJson(Map<String, dynamic> json) => BidModel(
      id: json['id'] as String,
      auctionId: json['auctionId'] as String,
      bidderId: json['bidderId'] as String,
      bidderName: json['bidderName'] as String,
      amount: (json['amount'] as num).toDouble(),
      timestamp: DateTime.parse(json['timestamp'] as String),
      isWinning: json['isWinning'] as bool? ?? false,
    );

Map<String, dynamic> _$BidModelToJson(BidModel instance) => <String, dynamic>{
      'id': instance.id,
      'auctionId': instance.auctionId,
      'bidderId': instance.bidderId,
      'bidderName': instance.bidderName,
      'amount': instance.amount,
      'timestamp': instance.timestamp.toIso8601String(),
      'isWinning': instance.isWinning,
    };

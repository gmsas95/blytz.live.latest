import 'package:json_annotation/json_annotation.dart';

part 'bid_model.g.dart';

@JsonSerializable()
class BidModel {

  BidModel({
    required this.id,
    required this.auctionId,
    required this.bidderId,
    required this.bidderName,
    required this.amount,
    required this.timestamp,
    this.isWinning = false,
  });

  factory BidModel.fromJson(Map<String, dynamic> json) =>
      _$BidModelFromJson(json);
  final String id;
  final String auctionId;
  final String bidderId;
  final String bidderName;
  final double amount;
  final DateTime timestamp;
  @JsonKey(defaultValue: false)
  final bool isWinning;

  Map<String, dynamic> toJson() => _$BidModelToJson(this);

  String get formattedAmount => '\$${amount.toStringAsFixed(2)}';

  BidModel copyWith({
    String? id,
    String? auctionId,
    String? bidderId,
    String? bidderName,
    double? amount,
    DateTime? timestamp,
    bool? isWinning,
  }) {
    return BidModel(
      id: id ?? this.id,
      auctionId: auctionId ?? this.auctionId,
      bidderId: bidderId ?? this.bidderId,
      bidderName: bidderName ?? this.bidderName,
      amount: amount ?? this.amount,
      timestamp: timestamp ?? this.timestamp,
      isWinning: isWinning ?? this.isWinning,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is BidModel &&
        other.id == id &&
        other.auctionId == auctionId &&
        other.bidderId == bidderId &&
        other.bidderName == bidderName &&
        other.amount == amount &&
        other.timestamp == timestamp &&
        other.isWinning == isWinning;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        auctionId.hashCode ^
        bidderId.hashCode ^
        bidderName.hashCode ^
        amount.hashCode ^
        timestamp.hashCode ^
        isWinning.hashCode;
  }

  @override
  String toString() {
    return 'BidModel(id: $id, auctionId: $auctionId, bidderId: $bidderId, '
        'bidderName: $bidderName, amount: $amount, timestamp: $timestamp, '
        'isWinning: $isWinning)';
  }
}
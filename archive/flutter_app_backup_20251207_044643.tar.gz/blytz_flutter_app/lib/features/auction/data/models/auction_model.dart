import 'package:equatable/equatable.dart';
import 'package:intl/intl.dart';

class AuctionModel extends Equatable {
  const AuctionModel({
    required this.id,
    required this.title,
    required this.description,
    required this.product,
    required this.sellerId,
    required this.sellerName,
    required this.startingPrice, required this.currentBid, required this.startTime, required this.endTime, this.sellerAvatar,
    this.reservePrice,
    this.status = 'active',
    this.totalBids = 0,
    this.images = const [],
    this.categories = const [],
    this.isActive = true,
    this.isFeatured = false,
    this.watchers = 0,
  });

  factory AuctionModel.fromJson(Map<String, dynamic> json) {
    return AuctionModel(
      id: json['id'] as String? ?? '',
      title: json['title'] as String? ?? '',
      description: json['description'] as String? ?? '',
      product: json['product'] != null
          ? ProductModel.fromJson(json['product'] as Map<String, dynamic>)
          : null,
      sellerId: json['sellerId'] as String? ?? '',
      sellerName: json['sellerName'] as String? ?? '',
      sellerAvatar: json['sellerAvatar'] as String?,
      startingPrice: (json['startingPrice'] as num?)?.toDouble() ?? 0.0,
      currentBid: (json['currentBid'] as num?)?.toDouble() ?? 0.0,
      reservePrice: (json['reservePrice'] as num?)?.toDouble(),
      startTime: json['startTime'] != null
          ? DateTime.parse(json['startTime'] as String)
          : DateTime.now(),
      endTime: json['endTime'] != null
          ? DateTime.parse(json['endTime'] as String)
          : DateTime.now().add(const Duration(hours: 1)),
      status: json['status'] as String? ?? 'active',
      totalBids: json['totalBids'] as int? ?? 0,
      images: (json['images'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList() ?? [],
      categories: (json['categories'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList() ?? [],
      isActive: json['isActive'] as bool? ?? true,
      isFeatured: json['isFeatured'] as bool? ?? false,
      watchers: json['watchers'] as int? ?? 0,
    );
  }

  final String id;
  final String title;
  final String description;
  final ProductModel? product;
  final String sellerId;
  final String sellerName;
  final String? sellerAvatar;
  final double startingPrice;
  final double currentBid;
  final double? reservePrice;
  final DateTime startTime;
  final DateTime endTime;
  final String status;
  final int totalBids;
  final List<String> images;
  final List<String> categories;
  final bool isActive;
  final bool isFeatured;
  final int watchers;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'product': product?.toJson(),
      'sellerId': sellerId,
      'sellerName': sellerName,
      'sellerAvatar': sellerAvatar,
      'startingPrice': startingPrice,
      'currentBid': currentBid,
      'reservePrice': reservePrice,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'status': status,
      'totalBids': totalBids,
      'images': images,
      'categories': categories,
      'isActive': isActive,
      'isFeatured': isFeatured,
      'watchers': watchers,
    };
  }

  AuctionModel copyWith({
    String? id,
    String? title,
    String? description,
    ProductModel? product,
    String? sellerId,
    String? sellerName,
    String? sellerAvatar,
    double? startingPrice,
    double? currentBid,
    double? reservePrice,
    DateTime? startTime,
    DateTime? endTime,
    String? status,
    int? totalBids,
    List<String>? images,
    List<String>? categories,
    bool? isActive,
    bool? isFeatured,
    int? watchers,
  }) {
    return AuctionModel(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      product: product ?? this.product,
      sellerId: sellerId ?? this.sellerId,
      sellerName: sellerName ?? this.sellerName,
      sellerAvatar: sellerAvatar ?? this.sellerAvatar,
      startingPrice: startingPrice ?? this.startingPrice,
      currentBid: currentBid ?? this.currentBid,
      reservePrice: reservePrice ?? this.reservePrice,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      status: status ?? this.status,
      totalBids: totalBids ?? this.totalBids,
      images: images ?? this.images,
      categories: categories ?? this.categories,
      isActive: isActive ?? this.isActive,
      isFeatured: isFeatured ?? this.isFeatured,
      watchers: watchers ?? this.watchers,
    );
  }

  // Helper getters
  bool get isEnded => DateTime.now().isAfter(endTime);
  bool get isStarted => DateTime.now().isAfter(startTime);
  bool get isEndingSoon {
    final timeUntilEnd = endTime.difference(DateTime.now());
    return timeUntilEnd.inMinutes <= 15 && timeUntilEnd.inMinutes > 0;
  }

  String get timeLeft {
    final now = DateTime.now();
    if (now.isBefore(startTime)) {
      return _formatDuration(startTime.difference(now));
    } else if (now.isBefore(endTime)) {
      return _formatDuration(endTime.difference(now));
    } else {
      return 'Ended';
    }
  }

  String _formatDuration(Duration duration) {
    if (duration.inDays > 0) {
      return '${duration.inDays}d ${duration.inHours % 24}h';
    } else if (duration.inHours > 0) {
      return '${duration.inHours}h ${duration.inMinutes % 60}m';
    } else {
      return '${duration.inMinutes}m';
    }
  }

  String get formattedCurrentBid {
    return NumberFormat.currency(symbol: r'$', decimalDigits: 2).format(currentBid);
  }

  String get formattedStartingPrice {
    return NumberFormat.currency(symbol: r'$', decimalDigits: 2).format(startingPrice);
  }

  @override
  List<Object?> get props => [
        id,
        title,
        description,
        product,
        sellerId,
        sellerName,
        sellerAvatar,
        startingPrice,
        currentBid,
        reservePrice,
        startTime,
        endTime,
        status,
        totalBids,
        images,
        categories,
        isActive,
        isFeatured,
        watchers,
      ];
}

class ProductModel extends Equatable {
  const ProductModel({
    required this.id,
    required this.name,
    this.description,
    this.condition,
    this.brand,
    this.model,
    this.year,
    this.dimensions,
    this.weight,
    this.images = const [],
    this.categories = const [],
  });

  factory ProductModel.fromJson(Map<String, dynamic> json) {
    return ProductModel(
      id: json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      description: json['description'] as String?,
      condition: json['condition'] as String?,
      brand: json['brand'] as String?,
      model: json['model'] as String?,
      year: json['year'] as int?,
      dimensions: json['dimensions'] as String?,
      weight: (json['weight'] as num?)?.toDouble(),
      images: (json['images'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList() ?? [],
      categories: (json['categories'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList() ?? [],
    );
  }

  final String id;
  final String name;
  final String? description;
  final String? condition;
  final String? brand;
  final String? model;
  final int? year;
  final String? dimensions;
  final double? weight;
  final List<String> images;
  final List<String> categories;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'condition': condition,
      'brand': brand,
      'model': model,
      'year': year,
      'dimensions': dimensions,
      'weight': weight,
      'images': images,
      'categories': categories,
    };
  }

  @override
  List<Object?> get props => [
        id,
        name,
        description,
        condition,
        brand,
        model,
        year,
        dimensions,
        weight,
        images,
        categories,
      ];
}

class BidModel extends Equatable {
  const BidModel({
    required this.id,
    required this.auctionId,
    required this.bidderId,
    required this.bidderName,
    required this.amount, required this.timestamp, this.bidderAvatar,
    this.isWinning = false,
  });

  factory BidModel.fromJson(Map<String, dynamic> json) {
    return BidModel(
      id: json['id'] as String? ?? '',
      auctionId: json['auctionId'] as String? ?? '',
      bidderId: json['bidderId'] as String? ?? '',
      bidderName: json['bidderName'] as String? ?? '',
      bidderAvatar: json['bidderAvatar'] as String?,
      amount: (json['amount'] as num?)?.toDouble() ?? 0.0,
      timestamp: json['timestamp'] != null
          ? DateTime.parse(json['timestamp'] as String)
          : DateTime.now(),
      isWinning: json['isWinning'] as bool? ?? false,
    );
  }

  final String id;
  final String auctionId;
  final String bidderId;
  final String bidderName;
  final String? bidderAvatar;
  final double amount;
  final DateTime timestamp;
  final bool isWinning;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'auctionId': auctionId,
      'bidderId': bidderId,
      'bidderName': bidderName,
      'bidderAvatar': bidderAvatar,
      'amount': amount,
      'timestamp': timestamp.toIso8601String(),
      'isWinning': isWinning,
    };
  }

  String get formattedAmount {
    return NumberFormat.currency(symbol: r'$', decimalDigits: 2).format(amount);
  }

  String get formattedTime {
    return DateFormat('MMM dd, yyyy HH:mm').format(timestamp);
  }

  @override
  List<Object?> get props => [
        id,
        auctionId,
        bidderId,
        bidderName,
        bidderAvatar,
        amount,
        timestamp,
        isWinning,
      ];
}
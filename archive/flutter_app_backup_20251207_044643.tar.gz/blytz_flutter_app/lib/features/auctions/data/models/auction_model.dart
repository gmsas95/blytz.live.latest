import 'package:json_annotation/json_annotation.dart';
import 'package:blytz_flutter_app/features/auth/data/models/user_model.dart';

part 'auction_model.g.dart';

@JsonSerializable()
class AuctionModel {

  AuctionModel({
    required this.id,
    required this.title,
    required this.description,
    required this.productId,
    required this.sellerId, required this.startingPrice, required this.currentPrice, required this.startTime, required this.endTime, required this.status, required this.createdAt, required this.updatedAt, this.product,
    this.seller,
    this.buyNowPrice,
    this.bids = const [],
    this.viewCount,
    this.watchCount,
    this.images = const [],
    this.categories = const [],
    this.metadata,
  });

  factory AuctionModel.fromJson(Map<String, dynamic> json) =>
      _$AuctionModelFromJson(json);
  final String id;
  final String title;
  final String description;
  final String productId;
  final ProductModel? product;
  final String sellerId;
  final UserModel? seller;
  final double startingPrice;
  final double currentPrice;
  final double? buyNowPrice;
  final DateTime startTime;
  final DateTime endTime;
  final String status;
  final List<BidModel> bids;
  final int? viewCount;
  final int? watchCount;
  final List<String> images;
  final List<String> categories;
  final Map<String, dynamic>? metadata;
  final DateTime createdAt;
  final DateTime updatedAt;

  Map<String, dynamic> toJson() => _$AuctionModelToJson(this);

  bool get isActive => status == 'active';
  
  bool get isEnded => status == 'ended';
  
  bool get isScheduled => status == 'scheduled';
  
  bool get isCancelled => status == 'cancelled';
  
  bool get hasBids => bids.isNotEmpty;
  
  BidModel? get highestBid => hasBids ? bids.first : null;
  
  int get totalBids => bids.length;
  
  bool get isEndingSoon {
    final now = DateTime.now();
    final timeLeft = endTime.difference(now);
    return timeLeft.inHours <= 1 && timeLeft.inMinutes > 0;
  }
  
  double get currentBidAmount => hasBids ? highestBid!.amount : currentPrice;
  
  String get timeLeft {
    final now = DateTime.now();
    if (now.isAfter(endTime)) return 'Ended';
    
    final difference = endTime.difference(now);
    if (difference.inDays > 0) {
      return '${difference.inDays}d ${difference.inHours % 24}h';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ${difference.inMinutes % 60}m';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m';
    } else {
      return 'Ending soon';
    }
  }
}

@JsonSerializable()
class BidModel {

  BidModel({
    required this.id,
    required this.auctionId,
    required this.userId,
    required this.amount, required this.timestamp, this.user,
    this.isWinning = false,
    this.metadata,
  });

  factory BidModel.fromJson(Map<String, dynamic> json) =>
      _$BidModelFromJson(json);
  final String id;
  final String auctionId;
  final String userId;
  final UserModel? user;
  final double amount;
  final DateTime timestamp;
  final bool isWinning;
  final Map<String, dynamic>? metadata;

  Map<String, dynamic> toJson() => _$BidModelToJson(this);

  String get formattedAmount => '\$${amount.toStringAsFixed(2)}';
  
  String get timeAgo {
    final now = DateTime.now();
    final difference = now.difference(timestamp);
    
    if (difference.inMinutes < 1) return 'Just now';
    if (difference.inMinutes < 60) return '${difference.inMinutes}m ago';
    if (difference.inHours < 24) return '${difference.inHours}h ago';
    return '${difference.inDays}d ago';
  }
}

@JsonSerializable()
class ProductModel {

  ProductModel({
    required this.id,
    required this.name,
    required this.description,
    required this.category,
    required this.location, required this.createdAt, required this.updatedAt, this.subcategories = const [],
    this.images = const [],
    this.specifications = const {},
    this.estimatedValue,
    this.brand,
    this.model,
    this.condition,
    this.color,
    this.dimensions,
    this.weight,
    this.isAvailable = true,
  });

  factory ProductModel.fromJson(Map<String, dynamic> json) =>
      _$ProductModelFromJson(json);
  final String id;
  final String name;
  final String description;
  final String category;
  final List<String> subcategories;
  final List<String> images;
  final Map<String, dynamic> specifications;
  final double? estimatedValue;
  final String? brand;
  final String? model;
  final String? condition;
  final String? color;
  final Map<String, dynamic>? dimensions;
  final double? weight;
  final String location;
  final bool isAvailable;
  final DateTime createdAt;
  final DateTime updatedAt;

  Map<String, dynamic> toJson() => _$ProductModelToJson(this);

  String get primaryImage => images.isNotEmpty ? images.first : '';
  
  String get formattedEstimatedValue => 
      estimatedValue != null ? '\$${estimatedValue!.toStringAsFixed(2)}' : 'N/A';
  
  String get displayName => name.length > 50 ? '${name.substring(0, 50)}...' : name;
}

@JsonSerializable()
class BidRequest {

  BidRequest({
    required this.amount,
    this.isAutoBid,
  });

  factory BidRequest.fromJson(Map<String, dynamic> json) =>
      _$BidRequestFromJson(json);
  final double amount;
  final bool? isAutoBid;

  Map<String, dynamic> toJson() => _$BidRequestToJson(this);
}

@JsonSerializable()
class BidResponse {

  BidResponse({
    required this.bid,
    required this.isWinning,
    this.message,
  });

  factory BidResponse.fromJson(Map<String, dynamic> json) =>
      _$BidResponseFromJson(json);
  final BidModel bid;
  final bool isWinning;
  final String? message;

  Map<String, dynamic> toJson() => _$BidResponseToJson(this);
}
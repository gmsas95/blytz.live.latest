// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auction_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AuctionModel _$AuctionModelFromJson(Map<String, dynamic> json) => AuctionModel(
      id: json['id'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      productId: json['productId'] as String,
      sellerId: json['sellerId'] as String,
      startingPrice: (json['startingPrice'] as num).toDouble(),
      currentPrice: (json['currentPrice'] as num).toDouble(),
      startTime: DateTime.parse(json['startTime'] as String),
      endTime: DateTime.parse(json['endTime'] as String),
      status: json['status'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      updatedAt: DateTime.parse(json['updatedAt'] as String),
      product: json['product'] == null
          ? null
          : ProductModel.fromJson(json['product'] as Map<String, dynamic>),
      seller: json['seller'] == null
          ? null
          : UserModel.fromJson(json['seller'] as Map<String, dynamic>),
      buyNowPrice: (json['buyNowPrice'] as num?)?.toDouble(),
      bids: (json['bids'] as List<dynamic>?)
              ?.map((e) => BidModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          const [],
      viewCount: (json['viewCount'] as num?)?.toInt(),
      watchCount: (json['watchCount'] as num?)?.toInt(),
      images: (json['images'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const [],
      categories: (json['categories'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const [],
      metadata: json['metadata'] as Map<String, dynamic>?,
    );

Map<String, dynamic> _$AuctionModelToJson(AuctionModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'title': instance.title,
      'description': instance.description,
      'productId': instance.productId,
      'product': instance.product,
      'sellerId': instance.sellerId,
      'seller': instance.seller,
      'startingPrice': instance.startingPrice,
      'currentPrice': instance.currentPrice,
      'buyNowPrice': instance.buyNowPrice,
      'startTime': instance.startTime.toIso8601String(),
      'endTime': instance.endTime.toIso8601String(),
      'status': instance.status,
      'bids': instance.bids,
      'viewCount': instance.viewCount,
      'watchCount': instance.watchCount,
      'images': instance.images,
      'categories': instance.categories,
      'metadata': instance.metadata,
      'createdAt': instance.createdAt.toIso8601String(),
      'updatedAt': instance.updatedAt.toIso8601String(),
    };

BidModel _$BidModelFromJson(Map<String, dynamic> json) => BidModel(
      id: json['id'] as String,
      auctionId: json['auctionId'] as String,
      userId: json['userId'] as String,
      amount: (json['amount'] as num).toDouble(),
      timestamp: DateTime.parse(json['timestamp'] as String),
      user: json['user'] == null
          ? null
          : UserModel.fromJson(json['user'] as Map<String, dynamic>),
      isWinning: json['isWinning'] as bool? ?? false,
      metadata: json['metadata'] as Map<String, dynamic>?,
    );

Map<String, dynamic> _$BidModelToJson(BidModel instance) => <String, dynamic>{
      'id': instance.id,
      'auctionId': instance.auctionId,
      'userId': instance.userId,
      'user': instance.user,
      'amount': instance.amount,
      'timestamp': instance.timestamp.toIso8601String(),
      'isWinning': instance.isWinning,
      'metadata': instance.metadata,
    };

ProductModel _$ProductModelFromJson(Map<String, dynamic> json) => ProductModel(
      id: json['id'] as String,
      name: json['name'] as String,
      description: json['description'] as String,
      category: json['category'] as String,
      location: json['location'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      updatedAt: DateTime.parse(json['updatedAt'] as String),
      subcategories: (json['subcategories'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const [],
      images: (json['images'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const [],
      specifications:
          json['specifications'] as Map<String, dynamic>? ?? const {},
      estimatedValue: (json['estimatedValue'] as num?)?.toDouble(),
      brand: json['brand'] as String?,
      model: json['model'] as String?,
      condition: json['condition'] as String?,
      color: json['color'] as String?,
      dimensions: json['dimensions'] as Map<String, dynamic>?,
      weight: (json['weight'] as num?)?.toDouble(),
      isAvailable: json['isAvailable'] as bool? ?? true,
    );

Map<String, dynamic> _$ProductModelToJson(ProductModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'description': instance.description,
      'category': instance.category,
      'subcategories': instance.subcategories,
      'images': instance.images,
      'specifications': instance.specifications,
      'estimatedValue': instance.estimatedValue,
      'brand': instance.brand,
      'model': instance.model,
      'condition': instance.condition,
      'color': instance.color,
      'dimensions': instance.dimensions,
      'weight': instance.weight,
      'location': instance.location,
      'isAvailable': instance.isAvailable,
      'createdAt': instance.createdAt.toIso8601String(),
      'updatedAt': instance.updatedAt.toIso8601String(),
    };

BidRequest _$BidRequestFromJson(Map<String, dynamic> json) => BidRequest(
      amount: (json['amount'] as num).toDouble(),
      isAutoBid: json['isAutoBid'] as bool?,
    );

Map<String, dynamic> _$BidRequestToJson(BidRequest instance) =>
    <String, dynamic>{
      'amount': instance.amount,
      'isAutoBid': instance.isAutoBid,
    };

BidResponse _$BidResponseFromJson(Map<String, dynamic> json) => BidResponse(
      bid: BidModel.fromJson(json['bid'] as Map<String, dynamic>),
      isWinning: json['isWinning'] as bool,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$BidResponseToJson(BidResponse instance) =>
    <String, dynamic>{
      'bid': instance.bid,
      'isWinning': instance.isWinning,
      'message': instance.message,
    };

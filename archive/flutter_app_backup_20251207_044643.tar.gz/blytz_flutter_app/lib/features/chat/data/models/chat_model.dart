import 'package:json_annotation/json_annotation.dart';
import 'package:blytz_flutter_app/features/auth/data/models/user_model.dart';

part 'chat_model.g.dart';

@JsonSerializable()
class ChatRoomModel {

  ChatRoomModel({
    required this.id,
    required this.name,
    required this.type, required this.createdAt, required this.updatedAt, this.description,
    this.auctionId,
    this.participantIds = const [],
    this.participants = const [],
    this.lastMessage,
    this.unreadCount = 0,
    this.isActive = true,
    this.metadata,
  });

  factory ChatRoomModel.fromJson(Map<String, dynamic> json) =>
      _$ChatRoomModelFromJson(json);
  final String id;
  final String name;
  final String? description;
  final String type;
  final String? auctionId;
  final List<String> participantIds;
  final List<UserModel> participants;
  final MessageModel? lastMessage;
  final int unreadCount;
  final bool isActive;
  final Map<String, dynamic>? metadata;
  final DateTime createdAt;
  final DateTime updatedAt;

  Map<String, dynamic> toJson() => _$ChatRoomModelToJson(this);

  bool get isAuctionChat => type == 'auction';
  
  bool get isPrivate => type == 'private';
  
  bool get isGroup => type == 'group';
  
  String get displayName {
    if (isAuctionChat && auctionId != null) {
      return 'Auction $auctionId';
    }
    return name;
  }
  
  String get lastMessagePreview {
    if (lastMessage == null) return 'No messages yet';
    return lastMessage!.content.length > 50 
        ? '${lastMessage!.content.substring(0, 50)}...'
        : lastMessage!.content;
  }
}

@JsonSerializable()
class MessageModel {

  MessageModel({
    required this.id,
    required this.roomId,
    required this.senderId,
    required this.content, required this.createdAt, required this.updatedAt, this.sender,
    this.type = MessageType.text,
    this.attachments,
    this.isEdited = false,
    this.editedAt,
    this.status = MessageStatus.sent,
    this.replyToId,
    this.replyTo,
    this.metadata,
  });

  factory MessageModel.fromJson(Map<String, dynamic> json) =>
      _$MessageModelFromJson(json);
  final String id;
  final String roomId;
  final String senderId;
  final UserModel? sender;
  final String content;
  final MessageType type;
  final Map<String, dynamic>? attachments;
  final bool isEdited;
  final DateTime? editedAt;
  final MessageStatus status;
  final String? replyToId;
  final MessageModel? replyTo;
  final Map<String, dynamic>? metadata;
  final DateTime createdAt;
  final DateTime updatedAt;

  Map<String, dynamic> toJson() => _$MessageModelToJson(this);

  bool get isText => type == MessageType.text;
  
  bool get isImage => type == MessageType.image;
  
  bool get isFile => type == MessageType.file;
  
  bool get isSystem => type == MessageType.system;
  
  bool get isFromMe => senderId == 'current_user'; // This should be dynamic
  
  String get timeFormatted {
    final now = DateTime.now();
    final difference = now.difference(createdAt);
    
    if (difference.inMinutes < 1) return 'Just now';
    if (difference.inHours < 1) return '${difference.inMinutes}m ago';
    if (difference.inDays < 1) return '${difference.inHours}h ago';
    if (difference.inDays < 7) return '${difference.inDays}d ago';
    
    return '${createdAt.day}/${createdAt.month}/${createdAt.year}';
  }
}

enum MessageType {
  @JsonValue('text')
  text,
  @JsonValue('image')
  image,
  @JsonValue('file')
  file,
  @JsonValue('system')
  system,
}

enum MessageStatus {
  @JsonValue('sending')
  sending,
  @JsonValue('sent')
  sent,
  @JsonValue('delivered')
  delivered,
  @JsonValue('read')
  read,
  @JsonValue('failed')
  failed,
}

@JsonSerializable()
class SendMessageRequest {

  SendMessageRequest({
    required this.content,
    this.type = MessageType.text,
    this.attachments,
    this.replyToId,
  });

  factory SendMessageRequest.fromJson(Map<String, dynamic> json) =>
      _$SendMessageRequestFromJson(json);
  final String content;
  final MessageType type;
  final Map<String, dynamic>? attachments;
  final String? replyToId;

  Map<String, dynamic> toJson() => _$SendMessageRequestToJson(this);
}


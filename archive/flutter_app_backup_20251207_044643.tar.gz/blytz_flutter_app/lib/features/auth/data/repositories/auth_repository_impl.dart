import 'package:blytz_flutter_app/core/network/api_client.dart';
import 'package:blytz_flutter_app/core/storage/secure_storage.dart';
import 'package:blytz_flutter_app/features/auth/data/models/auth_model.dart';
import 'package:blytz_flutter_app/core/errors/failures.dart';
import 'package:dio/dio.dart';
import 'package:either_dart/either.dart';

abstract class AuthRepository {
  Future<Either<Failure, AuthResponse>> login(LoginRequest request);
  Future<Either<Failure, AuthResponse>> register(RegisterRequest request);
  Future<Either<Failure, AuthResponse>> refreshToken(RefreshTokenRequest request);
  Future<Either<Failure, void>> logout();
  Future<Either<Failure, AuthModel>> getCurrentUser();
  Future<Either<Failure, AuthModel>> updateProfile(Map<String, dynamic> request);
  Future<Either<Failure, bool>> isTokenValid();
  Future<Either<Failure, String?>> getStoredToken();
}

class AuthRepositoryImpl implements AuthRepository {

  AuthRepositoryImpl({
    required ApiClient apiClient,
    required SecureStorage secureStorage,
    required Dio dio,
  }) : _apiClient = apiClient,
       _secureStorage = secureStorage,
       _dio = dio;
  final ApiClient _apiClient;
  final SecureStorage _secureStorage;
  final Dio _dio;

  @override
  Future<Either<Failure, AuthResponse>> login(LoginRequest request) async {
    try {
      final response = await _apiClient.login(request);

      // Store tokens securely
      await SecureStorage.storeToken(response.accessToken);
      await SecureStorage.storeRefreshToken(response.refreshToken);
      await SecureStorage.storeUserId(response.user.id);

      return Right(response);
    } on DioException catch (e) {
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, AuthResponse>> register(RegisterRequest request) async {
    try {
      final response = await _apiClient.register(request);

      // Store tokens securely
      await SecureStorage.storeToken(response.accessToken);
      await SecureStorage.storeRefreshToken(response.refreshToken);
      await SecureStorage.storeUserId(response.user.id);

      return Right(response);
    } on DioException catch (e) {
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, AuthResponse>> refreshToken(RefreshTokenRequest request) async {
    try {
      final response = await _apiClient.refreshToken(request);

      // Update stored tokens
      await SecureStorage.storeToken(response.accessToken);
      await SecureStorage.storeRefreshToken(response.refreshToken);

      return Right(response);
    } on DioException catch (e) {
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, void>> logout() async {
    try {
      final token = await SecureStorage.getToken();
      if (token != null) {
        await _apiClient.logout('Bearer $token');
      }

      // Clear stored tokens
      await SecureStorage.clearAll();

      return const Right(null);
    } on DioException catch (e) {
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, AuthModel>> getCurrentUser() async {
    try {
      final token = await SecureStorage.getToken();
      if (token == null) {
        return const Left(AuthFailure('No token found'));
      }

      final user = await _apiClient.getCurrentUser('Bearer $token');
      return Right(user);
    } on DioException catch (e) {
      if (e.response?.statusCode == 401) {
        // Token expired, clear it
        await SecureStorage.clearAll();
        return const Left(AuthFailure('Token expired, please login again'));
      }
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, AuthModel>> updateProfile(Map<String, dynamic> request) async {
    try {
      final token = await SecureStorage.getToken();
      if (token == null) {
        return const Left(AuthFailure('No token found'));
      }

      final updatedUser = await _apiClient.updateProfile('Bearer $token', request);
      return Right(updatedUser);
    } on DioException catch (e) {
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, bool>> isTokenValid() async {
    try {
      final token = await SecureStorage.getToken();
      if (token == null) {
        return const Right(false);
      }

      await _apiClient.verifyToken('Bearer $token');
      return const Right(true);
    } on DioException catch (e) {
      if (e.response?.statusCode == 401) {
        await SecureStorage.clearAll();
        return const Right(false);
      }
      return Left(ServerFailure.fromDioException(e));
    } catch (e) {
      return Left(ServerFailure(e.toString()));
    }
  }

  @override
  Future<Either<Failure, String?>> getStoredToken() async {
    try {
      final token = await SecureStorage.getToken();
      return Right(token);
    } catch (e) {
      return Left(CacheFailure(e.toString()));
    }
  }

  // Auto-refresh token method
  Future<Either<Failure, String>> getValidToken() async {
    final tokenResult = await getStoredToken();

    if (tokenResult.isLeft) {
      return const Left(AuthFailure('No token stored'));
    }

    final token = tokenResult.right;
    if (token == null) {
      return const Left(AuthFailure('No token found'));
    }

    // Check if token is still valid
    final validityResult = await isTokenValid();
    if (validityResult.isLeft) {
      return Left(validityResult.left);
    }

    if (!validityResult.right) {
      // Token is expired, try to refresh
      final refreshToken = await SecureStorage.getRefreshToken();
      if (refreshToken == null) {
        return const Left(AuthFailure('No refresh token found'));
      }

      try {
        final response = await _apiClient.refreshToken(RefreshTokenRequest(refreshToken: refreshToken));
        
        // Update stored tokens
        await SecureStorage.storeToken(response.accessToken);
        await SecureStorage.storeRefreshToken(response.refreshToken);
        
        return Right(response.accessToken);
      } on DioException catch (e) {
        return Left(ServerFailure.fromDioException(e));
      } catch (e) {
        return Left(ServerFailure(e.toString()));
      }
    }

    return Right(token);
  }
}
import 'package:json_annotation/json_annotation.dart';

part 'user_model.g.dart';

@JsonSerializable()
class UserModel {
  UserModel({
    required this.id,
    required this.email,
    required this.username,
    this.firstName,
    this.lastName,
    this.avatar,
    this.phoneNumber,
    this.isVerified = false,
    this.rating = 0.0,
    this.totalReviews = 0,
    this.memberSince,
    this.lastActive,
    this.address,
    this.preferences = const {},
    this.metadata,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) =>
      _$UserModelFromJson(json);

  final String id;
  final String email;
  final String username;
  final String? firstName;
  final String? lastName;
  final String? avatar;
  final String? phoneNumber;
  final bool isVerified;
  final double rating;
  final int totalReviews;
  final DateTime? memberSince;
  final DateTime? lastActive;
  final AddressModel? address;
  final Map<String, dynamic> preferences;
  final Map<String, dynamic>? metadata;

  Map<String, dynamic> toJson() => _$UserModelToJson(this);

  String get displayName => 
      firstName != null && lastName != null 
          ? '$firstName $lastName'
          : username;
          
  String get fullName => displayName;
  
  String get formattedRating => rating.toStringAsFixed(1);
  
  String get memberSinceFormatted {
    if (memberSince == null) return 'Unknown';
    final date = memberSince!;
    return '${date.month}/${date.year}';
  }
}

@JsonSerializable()
class AddressModel {
  AddressModel({
    this.street,
    this.city,
    this.state,
    this.postalCode,
    this.country,
    this.coordinates,
  });

  factory AddressModel.fromJson(Map<String, dynamic> json) =>
      _$AddressModelFromJson(json);

  final String? street;
  final String? city;
  final String? state;
  final String? postalCode;
  final String? country;
  final CoordinatesModel? coordinates;

  Map<String, dynamic> toJson() => _$AddressModelToJson(this);

  String get fullAddress {
    final parts = <String>[];
    if (street != null) parts.add(street!);
    if (city != null) parts.add(city!);
    if (state != null) parts.add(state!);
    if (postalCode != null) parts.add(postalCode!);
    if (country != null) parts.add(country!);
    return parts.join(', ');
  }
}

@JsonSerializable()
class CoordinatesModel {
  CoordinatesModel({
    required this.latitude,
    required this.longitude,
  });

  factory CoordinatesModel.fromJson(Map<String, dynamic> json) =>
      _$CoordinatesModelFromJson(json);

  final double latitude;
  final double longitude;

  Map<String, dynamic> toJson() => _$CoordinatesModelToJson(this);
}
import 'package:equatable/equatable.dart';

class AuctionModel extends Equatable {

  const AuctionModel({
    required this.id,
    required this.title,
    required this.description,
    required this.images,
    required this.categories,
    required this.currentBidAmount,
    required this.startingBid,
    required this.totalBids, required this.status, required this.startTime, required this.endTime, required this.isActive, required this.isEndingSoon, required this.timeLeft, this.reservePrice,
    this.sellerId,
    this.sellerName,
    this.highestBidderId,
    this.highestBidderName,
    this.watchCount,
  });

  factory AuctionModel.fromJson(Map<String, dynamic> json) {
    return AuctionModel(
      id: json['id'] as String? ?? '',
      title: json['title'] as String? ?? '',
      description: json['description'] as String? ?? '',
      images: (json['images'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          [],
      categories: (json['categories'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          [],
      currentBidAmount:
          (json['currentBidAmount'] as num?)?.toDouble() ?? 0.0,
      startingBid: (json['startingBid'] as num?)?.toDouble() ?? 0.0,
      reservePrice: (json['reservePrice'] as num?)?.toDouble(),
      totalBids: json['totalBids'] as int? ?? 0,
      status: json['status'] as String? ?? 'unknown',
      startTime: DateTime.parse(json['startTime'] as String? ?? DateTime.now().toIso8601String()),
      endTime: DateTime.parse(json['endTime'] as String? ?? DateTime.now().toIso8601String()),
      sellerId: json['sellerId'] as String?,
      sellerName: json['sellerName'] as String?,
      highestBidderId: json['highestBidderId'] as String?,
      highestBidderName: json['highestBidderName'] as String?,
      isActive: json['isActive'] as bool? ?? false,
      isEndingSoon: json['isEndingSoon'] as bool? ?? false,
      timeLeft: json['timeLeft'] as String? ?? '',
      watchCount: json['watchCount'] as int?,
    );
  }
  final String id;
  final String title;
  final String description;
  final List<String> images;
  final List<String> categories;
  final double currentBidAmount;
  final double startingBid;
  final double? reservePrice;
  final int totalBids;
  final String status;
  final DateTime startTime;
  final DateTime endTime;
  final String? sellerId;
  final String? sellerName;
  final String? highestBidderId;
  final String? highestBidderName;
  final bool isActive;
  final bool isEndingSoon;
  final String timeLeft;
  final int? watchCount;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'images': images,
      'categories': categories,
      'currentBidAmount': currentBidAmount,
      'startingBid': startingBid,
      'reservePrice': reservePrice,
      'totalBids': totalBids,
      'status': status,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'sellerId': sellerId,
      'sellerName': sellerName,
      'highestBidderId': highestBidderId,
      'highestBidderName': highestBidderName,
      'isActive': isActive,
      'isEndingSoon': isEndingSoon,
      'timeLeft': timeLeft,
      'watchCount': watchCount,
    };
  }

  AuctionModel copyWith({
    String? id,
    String? title,
    String? description,
    List<String>? images,
    List<String>? categories,
    double? currentBidAmount,
    double? startingBid,
    double? reservePrice,
    int? totalBids,
    String? status,
    DateTime? startTime,
    DateTime? endTime,
    String? sellerId,
    String? sellerName,
    String? highestBidderId,
    String? highestBidderName,
    bool? isActive,
    bool? isEndingSoon,
    String? timeLeft,
    int? watchCount,
  }) {
    return AuctionModel(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      images: images ?? this.images,
      categories: categories ?? this.categories,
      currentBidAmount: currentBidAmount ?? this.currentBidAmount,
      startingBid: startingBid ?? this.startingBid,
      reservePrice: reservePrice ?? this.reservePrice,
      totalBids: totalBids ?? this.totalBids,
      status: status ?? this.status,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      sellerId: sellerId ?? this.sellerId,
      sellerName: sellerName ?? this.sellerName,
      highestBidderId: highestBidderId ?? this.highestBidderId,
      highestBidderName: highestBidderName ?? this.highestBidderName,
      isActive: isActive ?? this.isActive,
      isEndingSoon: isEndingSoon ?? this.isEndingSoon,
      timeLeft: timeLeft ?? this.timeLeft,
      watchCount: watchCount ?? this.watchCount,
    );
  }

  @override
  List<Object?> get props => [
        id,
        title,
        description,
        images,
        categories,
        currentBidAmount,
        startingBid,
        reservePrice,
        totalBids,
        status,
        startTime,
        endTime,
        sellerId,
        sellerName,
        highestBidderId,
        highestBidderName,
        isActive,
        isEndingSoon,
        timeLeft,
        watchCount,
      ];
}
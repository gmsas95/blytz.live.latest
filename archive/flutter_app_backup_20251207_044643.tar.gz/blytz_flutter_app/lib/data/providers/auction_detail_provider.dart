import 'package:blytz_flutter_app/features/auctions/data/models/auction_model.dart';
import 'package:blytz_flutter_app/core/providers/app_providers.dart';
import 'package:blytz_flutter_app/core/storage/secure_storage.dart';
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// Provider for individual auction details
final auctionDetailProvider = FutureProvider.family<AuctionModel, String>((ref, auctionId) async {
  final apiClient = ref.watch(apiClientProvider);
  
  try {
    final response = await apiClient.getAuction(auctionId);
    return AuctionModel.fromJson(response['data'] as Map<String, dynamic>);
  } on DioException catch (e) {
    throw Exception(_handleDioError(e));
  } catch (e) {
    throw Exception('Failed to load auction details');
  }
});

// Provider for placing bids
final bidPlacementProvider = FutureProvider.family<bool, Map<String, dynamic>>((ref, bidData) async {
  final apiClient = ref.watch(apiClientProvider);
  final auctionId = bidData['auctionId'] as String;
  final amount = bidData['amount'] as double;
  
  try {
    final token = await SecureStorage.getToken();
    final response = await apiClient.placeBid(token ?? '', auctionId, {'amount': amount});
    return response['success'] as bool? ?? false;
  } on DioException catch (e) {
    throw Exception(_handleDioError(e));
  } catch (e) {
    throw Exception('Failed to place bid');
  }
});

// Provider for watching/unwatching auctions
final watchlistProvider = StateNotifierProvider<WatchlistNotifier, Set<String>>((ref) {
  return WatchlistNotifier();
});

class WatchlistNotifier extends StateNotifier<Set<String>> {
  WatchlistNotifier() : super({});

  void toggleWatch(String auctionId) {
    if (state.contains(auctionId)) {
      state = state.where((id) => id != auctionId).toSet();
    } else {
      state = {...state, auctionId};
    }
  }

  bool isWatching(String auctionId) {
    return state.contains(auctionId);
  }
}

String _handleDioError(DioException e) {
  switch (e.type) {
    case DioExceptionType.connectionTimeout:
    case DioExceptionType.sendTimeout:
    case DioExceptionType.receiveTimeout:
      return 'Connection timeout. Please check your internet connection.';
    case DioExceptionType.badResponse:
      final statusCode = e.response?.statusCode;
      switch (statusCode) {
        case 400:
          return 'Invalid bid amount.';
        case 401:
          return 'Please login to place a bid.';
        case 403:
          return 'You cannot bid on this auction.';
        case 404:
          return 'Auction not found.';
        case 409:
          return 'A higher bid has already been placed.';
        case 500:
          return 'Server error. Please try again later.';
        default:
          return 'HTTP Error: $statusCode';
      }
    case DioExceptionType.cancel:
      return 'Request cancelled.';
    case DioExceptionType.connectionError:
      return 'No internet connection.';
    case DioExceptionType.unknown:
    default:
      return 'An unexpected error occurred.';
  }
}
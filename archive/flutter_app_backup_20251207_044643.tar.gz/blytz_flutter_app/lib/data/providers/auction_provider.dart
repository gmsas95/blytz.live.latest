import 'package:blytz_flutter_app/core/network/api_client.dart';
import 'package:blytz_flutter_app/core/providers/app_providers.dart';
import 'package:blytz_flutter_app/features/auctions/data/models/auction_model.dart';
import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class AuctionListState {

  const AuctionListState({
    this.auctions = const [],
    this.isLoading = false,
    this.isLoadingMore = false,
    this.hasError = false,
    this.errorMessage,
    this.hasReachedMax = false,
    this.currentPage = 1,
  });
  final List<AuctionModel> auctions;
  final bool isLoading;
  final bool isLoadingMore;
  final bool hasError;
  final String? errorMessage;
  final bool hasReachedMax;
  final int currentPage;

  AuctionListState copyWith({
    List<AuctionModel>? auctions,
    bool? isLoading,
    bool? isLoadingMore,
    bool? hasError,
    String? errorMessage,
    bool? hasReachedMax,
    int? currentPage,
  }) {
    return AuctionListState(
      auctions: auctions ?? this.auctions,
      isLoading: isLoading ?? this.isLoading,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
      hasError: hasError ?? this.hasError,
      errorMessage: errorMessage ?? this.errorMessage,
      hasReachedMax: hasReachedMax ?? this.hasReachedMax,
      currentPage: currentPage ?? this.currentPage,
    );
  }
}

class AuctionListNotifier extends StateNotifier<AuctionListState> {

  AuctionListNotifier(this._apiClient) : super(const AuctionListState());
  final ApiClient _apiClient;
  static const int _pageSize = 20;

  Future<void> loadAuctions({bool refresh = false}) async {
    if (refresh) {
      state = state.copyWith(
        isLoading: true,
        hasError: false,
        auctions: [],
        currentPage: 1,
        hasReachedMax: false,
      );
    } else if (state.isLoading || state.hasReachedMax) {
      return;
    }

    try {
      final response = await _apiClient.getAuctions(
        page: refresh ? 1 : state.currentPage,
        limit: _pageSize,
        category: null, // category
        status: 'active', // status
      );

      final data = response['data'] as List<dynamic>? ?? [];
      final auctions = data.map((json) => AuctionModel.fromJson(json as Map<String, dynamic>)).toList();

      if (refresh) {
        state = state.copyWith(
          auctions: auctions,
          isLoading: false,
          currentPage: 2,
          hasReachedMax: auctions.length < _pageSize,
        );
      } else {
        final newAuctions = [...state.auctions, ...auctions];
        state = state.copyWith(
          auctions: newAuctions,
          isLoadingMore: false,
          currentPage: state.currentPage + 1,
          hasReachedMax: auctions.length < _pageSize,
        );
      }
    } on DioException catch (e) {
      state = state.copyWith(
        isLoading: false,
        isLoadingMore: false,
        hasError: true,
        errorMessage: _handleDioError(e),
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        isLoadingMore: false,
        hasError: true,
        errorMessage: 'An unexpected error occurred',
      );
    }
  }

  Future<void> loadMoreAuctions() async {
    if (state.isLoadingMore || state.hasReachedMax) return;

    state = state.copyWith(isLoadingMore: true);
    await loadAuctions();
  }

  Future<void> refreshAuctions() async {
    await loadAuctions(refresh: true);
  }

  String _handleDioError(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return 'Connection timeout. Please check your internet connection.';
      case DioExceptionType.badResponse:
        final statusCode = e.response?.statusCode;
        switch (statusCode) {
          case 400:
            return 'Bad request. Please try again.';
          case 401:
            return 'Unauthorized. Please login again.';
          case 403:
            return 'Access forbidden.';
          case 404:
            return 'Auctions not found.';
          case 500:
            return 'Server error. Please try again later.';
          default:
            return 'HTTP Error: $statusCode';
        }
      case DioExceptionType.cancel:
        return 'Request cancelled.';
      case DioExceptionType.connectionError:
        return 'No internet connection.';
      case DioExceptionType.unknown:
      default:
        return 'An unexpected error occurred.';
    }
  }
}

// Provider for the auction list
final auctionListProvider = StateNotifierProvider<AuctionListNotifier, AuctionListState>((ref) {
  final apiClient = ref.watch(apiClientProvider);
  return AuctionListNotifier(apiClient);
});

// Provider for filtered auctions (by category, search, etc.)
final filteredAuctionsProvider = Provider.family<List<AuctionModel>, Map<String, dynamic>>((ref, filters) {
  final auctionListState = ref.watch(auctionListProvider);
  final auctions = auctionListState.auctions;

  if (filters.isEmpty) return auctions;

  final searchQuery = filters['search'] as String?;
  final category = filters['category'] as String?;
  final status = filters['status'] as String?;
  final minPrice = filters['minPrice'] as double?;
  final maxPrice = filters['maxPrice'] as double?;

  return auctions.where((auction) {
    // Search filter
    if (searchQuery != null && searchQuery.isNotEmpty) {
      final query = searchQuery.toLowerCase();
      if (!auction.title.toLowerCase().contains(query) &&
          !auction.description.toLowerCase().contains(query)) {
        return false;
      }
    }

    // Category filter
    if (category != null && category.isNotEmpty) {
      if (!auction.categories.contains(category)) {
        return false;
      }
    }

    // Status filter
    if (status != null && status.isNotEmpty) {
      if (auction.status != status) {
        return false;
      }
    }

    // Price range filter
    if (minPrice != null && auction.currentBidAmount < minPrice) {
      return false;
    }
    if (maxPrice != null && auction.currentBidAmount > maxPrice) {
      return false;
    }

    return true;
  }).toList();
});

// Provider for auction categories
final auctionCategoriesProvider = FutureProvider<List<String>>((ref) async {
  final apiClient = ref.watch(apiClientProvider);
  try {
    final response = await apiClient.getAuctions(
      page: 1,
      limit: 1000,
      category: null,
      status: null,
    );
    final data = response['data']?['categories'] as List<dynamic>? ?? [];
    return data.map((category) => category.toString()).toList();
  } catch (e) {
    // Return default categories if API fails
    return [
      'Electronics',
      'Fashion',
      'Home & Garden',
      'Sports',
      'Books',
      'Toys',
      'Automotive',
      'Art',
      'Jewelry',
      'Other',
    ];
  }
});